import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:flutter_movie_tickets/models/models.dart';
import 'package:flutter_movie_tickets/services/services.dart';

part 'firebase_user_extension.dart';
part 'date_time_extension.dart';
part 'string_extension.dart';
