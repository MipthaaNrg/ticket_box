import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ListUser extends StatefulWidget {
  @override
  _ListUserState createState() => _ListUserState();
}

class _ListUserState extends State<ListUser> {
  Color primaryColor = Colors.white;
  Color secondaryColor = Colors.teal;
  Color logoGreen = Colors.orange;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController selectedLanguageController = TextEditingController();
  TextEditingController profilePictureController = TextEditingController();

  Map<String, dynamic> usersToAdd;
  CollectionReference collectionReference =
      Firestore.instance.collection("users");

  addUsers() {
    usersToAdd = {
      "name": nameController.text,
      "email": emailController.text,
      "selectedLanguage": selectedLanguageController.text,
      "profilePicture": profilePictureController.text,
    };
    collectionReference
        .add(usersToAdd)
        .whenComplete(() => print('Added to Database'));
  }

  _buildTextField(TextEditingController controller, String labelText) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
          color: primaryColor, border: Border.all(color: Colors.black)),
      child: TextField(
        controller: controller,
        style: TextStyle(color: Colors.black),
        decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 10),
            labelText: labelText,
            labelStyle: TextStyle(color: Colors.black),
            border: InputBorder.none),
      ),
    );
  }

  CollectionReference ref = Firestore.instance.collection('users');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: new Text(
            'Master Data User',
            style: TextStyle(
              fontFamily: 'Billabong',
              fontSize: 35,
            ),
          ),
          backgroundColor: Colors.blue,
          elevation: 0),
      backgroundColor: primaryColor,
      body: StreamBuilder(
        stream: ref.snapshots(),
        builder: (_, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.documents.length,
              itemBuilder: (context, index) {
                var doc = snapshot.data.documents[index].data();
                return ListTile(
                  leading: IconButton(
                    icon: Icon(Icons.edit),
                    color: Colors.blue,
                    onPressed: () {
                      nameController.text = doc['name'];
                      emailController.text = doc['email'];
                      selectedLanguageController.text = doc['selectedLanguage'];
                      profilePictureController.text = doc['profilePicture'];
                      showDialog(
                        context: context,
                        builder: (context) => Dialog(
                          child: Container(
                            color: primaryColor,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ListView(
                                shrinkWrap: true,
                                children: <Widget>[
                                  _buildTextField(nameController, "Name"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  _buildTextField(emailController, "Email"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  _buildTextField(
                                      selectedLanguageController, "Language"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  _buildTextField(profilePictureController,
                                      "Profil Picture"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  FlatButton(
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Text(
                                        'Update Product To Database',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    color: Colors.blue,
                                    onPressed: () {
                                      snapshot.data.documents[index].reference
                                          .update({
                                        "name": nameController.text,
                                        "email": emailController.text,
                                        "selectedLanguage":
                                            selectedLanguageController.text,
                                        "profilePicture":
                                            profilePictureController.text,
                                      }).whenComplete(
                                              () => Navigator.pop(context));
                                    },
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  FlatButton(
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Text(
                                        'Delete User From Database',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    color: Colors.red,
                                    onPressed: () {
                                      snapshot.data.documents[index].reference
                                          .delete();
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  title: Text(
                    "Name :" + doc['name'],
                    style: TextStyle(color: Colors.black),
                  ),
                  subtitle: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        doc['email'],
                        style: TextStyle(color: Colors.black),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Language :" + doc['selectedLanguage'],
                        style: TextStyle(color: Colors.black),
                      ),
                      Divider(
                        height: 30,
                        thickness: 3,
                        color: Colors.grey,
                      ),
                      SizedBox(
                        height: 15,
                      ),
                    ],
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                  ),
                  trailing: Image.network(
                    doc['profilePicture'],
                    height: 100,
                    fit: BoxFit.cover,
                    width: 80,
                  ),
                );
              },
            );
          } else
            return Text('');
        },
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     // Add your onPressed code here!
      //   },
      //   child: const Icon(Icons.add),
      //   backgroundColor: Colors.blue,
      // ),
    );
  }
}
