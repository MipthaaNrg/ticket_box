import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ListTransaksi extends StatefulWidget {
  @override
  _ListTransaksiState createState() => _ListTransaksiState();
}

class _ListTransaksiState extends State<ListTransaksi> {
  Color primaryColor = Colors.white;
  Color secondaryColor = Colors.teal;
  Color logoGreen = Colors.orange;

  TextEditingController subtitleController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController userIDController = TextEditingController();

  Map<String, dynamic> transactionsToAdd;
  CollectionReference collectionReference =
      Firestore.instance.collection("transactions");

  addTransactions() {
    transactionsToAdd = {
      "subtitle": subtitleController.text,
      "title": titleController.text,
      "userID": userIDController.text,
    };
    collectionReference
        .add(transactionsToAdd)
        .whenComplete(() => print('Added to Database'));
  }

  _buildTextField(TextEditingController controller, String labelText) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
          color: primaryColor, border: Border.all(color: Colors.black)),
      child: TextField(
        controller: controller,
        style: TextStyle(color: Colors.black),
        decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 10),
            labelText: labelText,
            labelStyle: TextStyle(color: Colors.black),
            border: InputBorder.none),
      ),
    );
  }

  CollectionReference ref = Firestore.instance.collection('transactions');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: new Text(
            'Master Data Transaksi',
            style: TextStyle(
              fontFamily: 'Billabong',
              fontSize: 35,
            ),
          ),
          backgroundColor: Colors.blue,
          elevation: 0),
      backgroundColor: primaryColor,
      body: StreamBuilder(
        stream: ref.snapshots(),
        builder: (_, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.documents.length,
              itemBuilder: (context, index) {
                var doc = snapshot.data.documents[index].data();
                return ListTile(
                  leading: IconButton(
                    icon: Icon(Icons.edit),
                    color: Colors.blue,
                    onPressed: () {
                      subtitleController.text = doc['subtitle'];
                      titleController.text = doc['title'];
                      userIDController.text = doc['userID'];

                      showDialog(
                        context: context,
                        builder: (context) => Dialog(
                          child: Container(
                            color: primaryColor,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ListView(
                                shrinkWrap: true,
                                children: <Widget>[
                                  _buildTextField(
                                      subtitleController, "Subtitle"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  _buildTextField(titleController, "Title"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  _buildTextField(userIDController, "User ID"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  FlatButton(
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Text(
                                        'Update Transaksi To Database',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    color: Colors.blue,
                                    onPressed: () {
                                      snapshot.data.documents[index].reference
                                          .update({
                                        "name": subtitleController.text,
                                        "bookingCode": titleController.text,
                                        "userID": userIDController.text,
                                      }).whenComplete(
                                              () => Navigator.pop(context));
                                    },
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  FlatButton(
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Text(
                                        'Delete From Database',
                                        style: TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    color: Colors.red,
                                    onPressed: () {
                                      snapshot.data.documents[index].reference
                                          .delete();
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  title: Text(
                    "Subtitle: " + doc['subtitle'],
                    style: TextStyle(color: Colors.black),
                  ),
                  subtitle: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Title: " + doc['title'],
                        style: TextStyle(color: Colors.black),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "User ID: " + doc['userID'],
                        style: TextStyle(color: Colors.black),
                      ),
                      Divider(
                        height: 30,
                        thickness: 3,
                        color: Colors.grey,
                      ),
                      SizedBox(
                        height: 15,
                      ),
                    ],
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                  ),
                );
              },
            );
          } else
            return Text('');
        },
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     // Add your onPressed code here!
      //   },
      //   child: const Icon(Icons.add),
      //   backgroundColor: Colors.blue,
      // ),
    );
  }
}
