part of 'pages.dart';

class SplashPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.orange,
        body: Container(
          padding: EdgeInsets.symmetric(horizontal: defaultMargin),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  height: size.height * 0.3,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/logo.png"))),
                ),
                Text(
                  "Watch a new movie much\neasier than any before",
                  //  style: whiteTextFont.copyWith(
                  style: TextStyle(
                    fontFamily: 'Billabong',
                    fontSize: 30,
                    fontWeight: FontWeight.w300,
                  ),
                  textAlign: TextAlign.center,
                ),
                Container(
                  width: 250,
                  height: 46,
                  margin: EdgeInsets.only(top: 30, bottom: 19),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        "Get Started",
                        style: whiteTextFont.copyWith(fontSize: 16),
                      ),
                      color: Colors.blue,
                      onPressed: () {
                        context
                            .read<PageBloc>()
                            .add(GoToRegistrationPage(RegistrationData()));
                      }),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "Already have an account? ",
                      style:
                          whiteTextFont.copyWith(fontWeight: FontWeight.w400),
                    ),
                    GestureDetector(
                      onTap: () {
                        context.read<PageBloc>().add(GoToLoginPage());
                      },
                      child: Text("Sign In",
                          style: TextStyle(
                            color: Colors.blue,
                            fontFamily: 'Billabong',
                            fontSize: 20,
                          )),
                    ),
                  ],
                ),
                Container(
                  width: 150,
                  height: 46,
                  margin: EdgeInsets.only(top: 30, bottom: 19),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        "I'm Admin",
                        style: whiteTextFont.copyWith(fontSize: 16),
                      ),
                      color: Colors.grey,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => MyApp()),
                        );
                      }),
                ),
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        "Copyright © 2021 ",
                        style:
                            whiteTextFont.copyWith(fontWeight: FontWeight.w400),
                      ),
                      Text(
                        "by. Mifta  ",
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Billabong',
                            fontWeight: FontWeight.w400),
                      ),
                    ]),
              ]),
        ));
  }
}
