part of 'shared.dart';

String apiKey = "3244674e749986787b88f4e0b9213818";
String imageBaseURL = "https://image.tmdb.org/t/p/";

PageEvent prevPageEvent;
File imageFileToUpload;
